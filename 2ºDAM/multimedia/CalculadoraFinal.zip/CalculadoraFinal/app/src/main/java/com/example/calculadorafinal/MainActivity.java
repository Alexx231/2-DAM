package com.example.calculadorafinal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private String currentInput = "";
    private String operator = "";
    private double firstOperand = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editText = findViewById(R.id.editText);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                String buttonText = button.getText().toString();
                handleButtonClick(buttonText);
            }
        };

        int[] buttonIds = {
                R.id.boton0, R.id.boton1, R.id.boton2, R.id.boton3, R.id.boton4,
                R.id.boton5, R.id.boton6, R.id.boton7, R.id.boton8, R.id.boton9,
                R.id.mas, R.id.menos, R.id.multiplicar, R.id.dividir,
                R.id.punto, R.id.igual
        };

        for (int id : buttonIds) {
            findViewById(id).setOnClickListener(listener);
        }
    }

    private void handleButtonClick(String buttonText) {
        switch (buttonText) {
            case "+":
            case "-":
            case "*":
            case "/":
                operator = buttonText;
                firstOperand = Double.parseDouble(currentInput);
                currentInput = "";
                break;
            case "=":
                double secondOperand = Double.parseDouble(currentInput);
                double result = performOperation(firstOperand, secondOperand, operator);
                editText.setText(String.valueOf(result));
                currentInput = String.valueOf(result);
                operator = "";
                break;
            case ".":
                if (!currentInput.contains(".")) {
                    currentInput += buttonText;
                    editText.setText(currentInput);
                }
                break;
            default:
                currentInput += buttonText;
                editText.setText(currentInput);
                break;
        }
    }

    private double performOperation(double firstOperand, double secondOperand, String operator) {
        switch (operator) {
            case "+":
                return firstOperand + secondOperand;
            case "-":
                return firstOperand - secondOperand;
            case "*":
                return firstOperand * secondOperand;
            case "/":
                if (secondOperand != 0) {
                    return firstOperand / secondOperand;
                } else {
                    return 0; // Handle division by zero
                }
            default:
                return 0;
        }
    }
}