package com.example.tapgamealejandropawlukiewicz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    // Elementos de la interfaz de usuario
    private EditText emailText;
    private EditText passwordText;
    private Button botonRegistro;
    private Button botonInicioSesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Habilitar la visualización de borde a borde
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Ajustar el padding para las barras del sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializar los elementos de la interfaz de usuario
        emailText = findViewById(R.id.emailText);
        passwordText = findViewById(R.id.PasswordText);
        botonRegistro = findViewById(R.id.botonRegistro);
        botonInicioSesion = findViewById(R.id.botonIniciarSesion);

        // Configurar los listeners de los botones
        setup();
    }

    private void setup() {
        setTitle("Login");

        // Manejar el clic del botón de registro
        botonRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Verificar que los campos de email y contraseña no estén vacíos
                if (!emailText.getText().toString().isEmpty() && !passwordText.getText().toString().isEmpty()) {
                    // Crear un nuevo usuario con email y contraseña
                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(emailText.getText().toString(), passwordText.getText().toString())
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    // Obtener el usuario actual de Firebase
                                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                        if (user != null) {
                                            // Obtener la instancia de Firestore
                                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                                            // Crear un mapa para almacenar los datos del usuario
                                            Map<String, Object> userData = new HashMap<>();
                                            userData.put("email", user.getEmail());
                                            // Guardar los datos del usuario en Firestore
                                            db.collection("users").document(user.getUid())
                                                    .set(userData)
                                                    .addOnSuccessListener(aVoid -> {
                                                        // Navegar a MainActivity
                                                        showMainActivity();
                                                    });
                                        }

                                } else {
                                    // Manejar excepciones específicas de Firebase
                                    if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                        showAlert("Este correo electrónico ya está en uso.");
                                    } else {
                                        showAlert(task.getException().getMessage());
                                    }
                                }
                            });
                } else {
                    // Mostrar un mensaje de toast si los campos están vacíos
                    Toast.makeText(Login.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Manejar el clic del botón de inicio de sesión
        botonInicioSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Verificar que los campos de email y contraseña no estén vacíos
                if (!emailText.getText().toString().isEmpty() && !passwordText.getText().toString().isEmpty()) {
                    // Iniciar sesión con email y contraseña
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(emailText.getText().toString(), passwordText.getText().toString())
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    // Navegar a MainActivity si el inicio de sesión es exitoso
                                    showMainActivity();
                                } else {
                                    // Mostrar alerta de error si el inicio de sesión falla
                                    showAlert(task.getException().getMessage());
                                }
                            });
                } else {
                    // Mostrar un mensaje de toast si los campos están vacíos
                    Toast.makeText(Login.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Mostrar un cuadro de diálogo de alerta con un mensaje de error
    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage(message);
        builder.setPositiveButton("Aceptar", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Navegar a MainActivity
    private void showMainActivity() {
        Intent homeIntent = new Intent(this, MainActivity.class);
        startActivity(homeIntent);
        finish();
    }
}