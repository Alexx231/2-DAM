package com.example.tapgamealejandropawlukiewicz;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class PlayerLogActivity extends AppCompatActivity {

    // Variables para la lista de jugadores y el ListView
    private ListView playerListView;
    private ArrayList<String> playerLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_log);

        // Inicialización del ListView y la lista de jugadores
        playerListView = findViewById(R.id.playerListView);
        playerLog = new ArrayList<>();

        // Cargar los registros de los jugadores desde Firestore
        loadPlayerLogs();
    }

    // Método para cargar los registros de los jugadores desde Firestore
    private void loadPlayerLogs() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("playerLogs")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String username = document.getString("username");
                            Long score = document.getLong("score");
                            playerLog.add(username + ": " + score);
                        }
                        // Configuración del adaptador para mostrar la lista de jugadores
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, playerLog);
                        playerListView.setAdapter(adapter);
                    } else {
                        Toast.makeText(PlayerLogActivity.this, "Error al cargar los registros", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}