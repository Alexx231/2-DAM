package com.example.tapgamealejandropawlukiewicz;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // Variables para la puntuación, visualizadores, imagen del personaje, botón de logout, temporizador y nombre de usuario
    private int score = 0;
    private TextView visualizadorPuntuacion;
    private TextView visualizadorTiempo;
    private ImageView character;
    private Button botonLogout;
    private CountDownTimer countDownTimer;
    private static final long START_TIME_IN_MILLIS = 30000; // 30 segundos
    private boolean isGameFinished = false;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de los elementos de la interfaz
        visualizadorPuntuacion = findViewById(R.id.VisualizadorPuntuacion);
        visualizadorTiempo = findViewById(R.id.VisualizadorTiempo);
        character = findViewById(R.id.character);
        botonLogout = findViewById(R.id.BotonLogout);

        // Configuración del listener para el layout del juego
        findViewById(R.id.gameLayout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isGameFinished) {
                    jump();
                }
            }
        });

        // Configuración del listener para el visualizador de puntuación
        visualizadorPuntuacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent logIntent = new Intent(MainActivity.this, PlayerLogActivity.class);
                startActivity(logIntent);
            }
        });

        // Configuración del listener para el botón de logout
        botonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent loginIntent = new Intent(MainActivity.this, Login.class);
                startActivity(loginIntent);
                finish();
            }
        });

        // Configuración del listener para el personaje
        character.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isGameFinished) {
                    startGame();
                }
            }
        });

        // Solicitar el nombre de usuario
        promptUsername();
    }

    // Método para solicitar el nombre de usuario
    private void promptUsername() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Ingrese su nombre de usuario");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                username = input.getText().toString();
                startGame();
            }
        });
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    // Método para iniciar el juego
    private void startGame() {
        score = 0;
        visualizadorPuntuacion.setText("Puntuación: " + score);
        isGameFinished = false;
        findViewById(R.id.gameLayout).setEnabled(true);

        // Configuración del temporizador
        countDownTimer = new CountDownTimer(START_TIME_IN_MILLIS, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                visualizadorTiempo.setText("Tiempo: " + millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                findViewById(R.id.gameLayout).setEnabled(false);
                isGameFinished = true;
                Toast.makeText(MainActivity.this, "¡Tiempo terminado! Puntuación final: " + score, Toast.LENGTH_LONG).show();
                savePlayerLog(username, score);
            }
        }.start();
    }

    // Método para guardar el registro del jugador en Firestore
    private void savePlayerLog(String username, int score) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> playerData = new HashMap<>();
        playerData.put("username", username);
        playerData.put("score", score);

        db.collection("playerLogs")
                .add(playerData)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(MainActivity.this, "Puntuación guardada", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(MainActivity.this, "Error al guardar la puntuación", Toast.LENGTH_SHORT).show();
                });
    }

    // Método para realizar el salto del personaje
    private void jump() {
        Animation jumpAnimation = AnimationUtils.loadAnimation(this, R.anim.jump);
        character.startAnimation(jumpAnimation);
        score++;
        visualizadorPuntuacion.setText("Puntuación: " + score);
    }
}