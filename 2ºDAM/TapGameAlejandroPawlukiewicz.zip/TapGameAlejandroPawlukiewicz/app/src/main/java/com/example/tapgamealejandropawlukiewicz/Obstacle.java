package com.example.tapgamealejandropawlukiewicz;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import android.widget.ImageView;

public class Obstacle {
    private ImageView view;
    private int type;
    private float x, y;
    private int screenWidth;

    public Obstacle(Context context) {
        this.type = type;
        view = new ImageView(context);
        screenWidth = context.getResources().getDisplayMetrics().widthPixels;

        // Configure appearance based on type
        switch (type) {
            case 1:
                view.setImageResource(R.drawable.obstacle_type_1);
                break;
            case 2:
                view.setImageResource(R.drawable.obstacle_type_2);
                break;
            // Add more cases for different obstacle types
        }

        // Initialize position
        x = screenWidth;
        y = context.getResources().getDisplayMetrics().heightPixels - view.getDrawable().getIntrinsicHeight();
        view.setX(x);
        view.setY(y);
    }

    public void update() {
        // Move the obstacle
        x -= MainActivity.GAME_SPEED;
        view.setX(x);

        // Check if the obstacle is off-screen
        if (x + view.getWidth() < 0) {
            // Handle obstacle going off-screen (e.g., remove it from the game)
        }
    }

    public Rect getBounds() {
        return new Rect(
                (int)x,
                (int)y,
                (int)(x + view.getWidth()),
                (int)(y + view.getHeight())
        );
    }

    public View getView() {
        return view;
    }
}