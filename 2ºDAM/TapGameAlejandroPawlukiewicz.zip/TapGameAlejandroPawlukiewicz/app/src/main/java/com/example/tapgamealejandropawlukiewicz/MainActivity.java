package com.example.tapgamealejandropawlukiewicz; // Paquete de la aplicación

import android.content.DialogInterface; // Importación de la interfaz de diálogo
import android.content.Intent; // Importación de la clase Intent para cambiar de actividad
import android.os.Bundle; // Importación de la clase Bundle para pasar datos entre actividades
import android.os.CountDownTimer; // Importación de la clase CountDownTimer para el temporizador
import android.view.View; // Importación de la clase View para manejar la interfaz de usuario
import android.view.animation.Animation; // Importación de la clase Animation para animaciones
import android.view.animation.AnimationUtils; // Importación de la clase AnimationUtils para cargar animaciones
import android.widget.Button; // Importación de la clase Button para manejar botones
import android.widget.EditText; // Importación de la clase EditText para manejar campos de texto
import android.widget.ImageView; // Importación de la clase ImageView para manejar imágenes
import android.widget.TextView; // Importación de la clase TextView para manejar textos
import android.widget.Toast; // Importación de la clase Toast para mostrar mensajes emergentes

import androidx.appcompat.app.AlertDialog; // Importación de la clase AlertDialog para diálogos de alerta
import androidx.appcompat.app.AppCompatActivity; // Importación de la clase AppCompatActivity para actividades

import com.google.firebase.auth.FirebaseAuth; // Importación de la clase FirebaseAuth para autenticación
import com.google.firebase.firestore.FirebaseFirestore; // Importación de la clase FirebaseFirestore para la base de datos Firestore

import java.util.HashMap; // Importación de la clase HashMap para manejar mapas de datos
import java.util.Map; // Importación de la clase Map para manejar mapas de datos

public class MainActivity extends AppCompatActivity { // Definición de la clase MainActivity que extiende AppCompatActivity

    // Declaración de variables
    private int score = 0; // Variable para la puntuación
    private TextView visualizadorPuntuacion; // TextView para mostrar la puntuación
    private TextView visualizadorTiempo; // TextView para mostrar el tiempo
    private ImageView character; // ImageView para el personaje
    private Button botonLogout; // Botón para cerrar sesión
    private CountDownTimer countDownTimer; // Temporizador
    private static final long START_TIME_IN_MILLIS = 30000; // Tiempo inicial del temporizador en milisegundos (30 segundos)
    private boolean isGameFinished = false; // Variable para indicar si el juego ha terminado
    private String username; // Variable para el nombre de usuario

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Método onCreate que se ejecuta al iniciar la actividad
        super.onCreate(savedInstanceState); // Llamada al método onCreate de la superclase
        setContentView(R.layout.activity_main); // Establecer el diseño de la actividad

        // Inicialización de los elementos de la interfaz
        visualizadorPuntuacion = findViewById(R.id.VisualizadorPuntuacion); // Inicialización del TextView de la puntuación
        visualizadorTiempo = findViewById(R.id.VisualizadorTiempo); // Inicialización del TextView del tiempo
        character = findViewById(R.id.character); // Inicialización del ImageView del personaje
        botonLogout = findViewById(R.id.BotonLogout); // Inicialización del botón de logout

        // Configuración del listener para el layout del juego
        findViewById(R.id.gameLayout).setOnClickListener(new View.OnClickListener() { // Listener para el layout del juego
            @Override
            public void onClick(View v) { // Método onClick que se ejecuta al hacer clic
                if (!isGameFinished) { // Si el juego no ha terminado
                    jump(); // Llamar al método jump
                }
            }
        });

        // Configuración del listener para el visualizador de puntuación
        visualizadorPuntuacion.setOnClickListener(new View.OnClickListener() { // Listener para el TextView de la puntuación
            @Override
            public void onClick(View v) { // Método onClick que se ejecuta al hacer clic
                Intent logIntent = new Intent(MainActivity.this, PlayerLogActivity.class); // Crear un Intent para cambiar a PlayerLogActivity
                startActivity(logIntent); // Iniciar la actividad PlayerLogActivity
            }
        });

        // Configuración del listener para el botón de logout
        botonLogout.setOnClickListener(new View.OnClickListener() { // Listener para el botón de logout
            @Override
            public void onClick(View v) { // Método onClick que se ejecuta al hacer clic
                FirebaseAuth.getInstance().signOut(); // Cerrar sesión en Firebase
                Intent loginIntent = new Intent(MainActivity.this, Login.class); // Crear un Intent para cambiar a Login
                startActivity(loginIntent); // Iniciar la actividad Login
                finish(); // Finalizar la actividad actual
            }
        });

        // Configuración del listener para el personaje
        character.setOnClickListener(new View.OnClickListener() { // Listener para el ImageView del personaje
            @Override
            public void onClick(View v) { // Método onClick que se ejecuta al hacer clic
                if (isGameFinished) { // Si el juego ha terminado
                    startGame(); // Reiniciar el juego
                }
            }
        });

        // Solicitar el nombre de usuario
        promptUsername(); // Llamar al método promptUsername
    }

    // Método para solicitar el nombre de usuario
    private void promptUsername() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this); // Crear un AlertDialog
        builder.setTitle("Ingrese su nombre de usuario"); // Establecer el título del diálogo

        final EditText input = new EditText(this); // Crear un EditText para ingresar el nombre de usuario
        builder.setView(input); // Establecer el EditText en el diálogo

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // Botón positivo del diálogo
            @Override
            public void onClick(DialogInterface dialog, int which) { // Método onClick que se ejecuta al hacer clic en el botón
                username = input.getText().toString(); // Obtener el nombre de usuario del EditText
                startGame(); // Iniciar el juego
            }
        });
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() { // Botón negativo del diálogo
            @Override
            public void onClick(DialogInterface dialog, int which) { // Método onClick que se ejecuta al hacer clic en el botón
                dialog.cancel(); // Cancelar el diálogo
            }
        });

        builder.show(); // Mostrar el diálogo
    }

    // Método para iniciar el juego
    private void startGame() {
        score = 0; // Reiniciar la puntuación
        visualizadorPuntuacion.setText("Puntuación: " + score); // Actualizar el TextView de la puntuación
        isGameFinished = false; // Indicar que el juego no ha terminado
        findViewById(R.id.gameLayout).setEnabled(true); // Habilitar el layout del juego

        // Configuración del temporizador
        countDownTimer = new CountDownTimer(START_TIME_IN_MILLIS, 1000) { // Crear un CountDownTimer con el tiempo inicial y el intervalo de 1 segundo
            @Override
            public void onTick(long millisUntilFinished) { // Método onTick que se ejecuta en cada intervalo
                visualizadorTiempo.setText("Tiempo: " + millisUntilFinished / 1000); // Actualizar el TextView del tiempo
            }

            @Override
            public void onFinish() { // Método onFinish que se ejecuta cuando el temporizador termina
                findViewById(R.id.gameLayout).setEnabled(false); // Deshabilitar el layout del juego
                isGameFinished = true; // Indicar que el juego ha terminado
                Toast.makeText(MainActivity.this, "¡Tiempo terminado! Puntuación final: " + score, Toast.LENGTH_LONG).show(); // Mostrar un mensaje con la puntuación final
                savePlayerLog(username, score); // Guardar el registro del jugador
            }
        }.start(); // Iniciar el temporizador
    }

    // Método para guardar el registro del jugador en Firestore
    private void savePlayerLog(String username, int score) {
        FirebaseFirestore db = FirebaseFirestore.getInstance(); // Obtener la instancia de Firestore
        Map<String, Object> playerData = new HashMap<>(); // Crear un mapa para los datos del jugador
        playerData.put("username", username); // Agregar el nombre de usuario al mapa
        playerData.put("score", score); // Agregar la puntuación al mapa

        db.collection("playerLogs") // Obtener la colección "playerLogs" en Firestore
                .add(playerData); // Agregar los datos del jugador a la colección
    }

    // Método para realizar el salto del personaje
    private void jump() {
        Animation jumpAnimation = AnimationUtils.loadAnimation(this, R.anim.jump); // Cargar la animación de salto
        character.startAnimation(jumpAnimation); // Iniciar la animación en el ImageView del personaje
        score++; // Incrementar la puntuación
        visualizadorPuntuacion.setText("Puntuación: " + score); // Actualizar el TextView de la puntuación
    }
}