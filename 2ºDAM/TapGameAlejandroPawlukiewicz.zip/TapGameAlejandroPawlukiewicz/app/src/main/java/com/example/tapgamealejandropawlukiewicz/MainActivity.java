package com.example.tapgamealejandropawlukiewicz;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ImageView character;
    private float currentY;
    private boolean isJumping = false;
    private int score = 0;
    private ArrayList<Obstacle> obstacles;
    private Handler gameHandler;
    public static final int GAME_SPEED = 16; // ~60 FPS
    private TextView scoreText;
    private CountDownTimer countDownTimer;
    private static final long START_TIME_IN_MILLIS = 30000; // 30 seconds
    private boolean isGameFinished = false;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        character = findViewById(R.id.character);
        scoreText = findViewById(R.id.scoreText);
        obstacles = new ArrayList<>();
        gameHandler = new Handler();

        // Initialize the game
        setupGame();

        // Touch detector
        findViewById(R.id.gameLayout).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN && !isJumping) {
                jump();
                return true;
            }
            return false;
        });

        // Request username
        promptUsername();
    }

    private void setupGame() {
        // Start game loop
        gameHandler.post(new Runnable() {
            @Override
            public void run() {
                updateGame();
                gameHandler.postDelayed(this, GAME_SPEED);
            }
        });

        // Generate obstacles periodically
        generateObstacles();

        // Setup audio
        setupAudio();
    }

    private void setupAudio() {
        MediaPlayer backgroundMusic = MediaPlayer.create(this, R.raw.game_music);
        backgroundMusic.setLooping(true);
        backgroundMusic.start();
    }

    private void updateGame() {
        // Update character position
        if (isJumping) {
            // Apply jump physics
            applyGravity();
        }

        // Check collisions
        checkCollisions();

        // Update score
        updateScore();
    }

    private void jump() {
        isJumping = true;
        Animation jumpAnim = AnimationUtils.loadAnimation(this, R.anim.jump);
        character.startAnimation(jumpAnim);
    }

    private void generateObstacles() {
        // Logic to generate random obstacles
        // Example: Add a new obstacle every few seconds
        gameHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isGameFinished) {
                    Obstacle obstacle = new Obstacle(MainActivity.this);
                    obstacles.add(obstacle);
                    generateObstacles();
                }
            }
        }, 2000); // Generate a new obstacle every 2 seconds
    }

    private void checkCollisions() {
        // Collision detector
        Rect characterBounds = new Rect();
        character.getHitRect(characterBounds);

        for (Obstacle obstacle : obstacles) {
            if (Rect.intersects(characterBounds, obstacle.getBounds())) {
                gameOver();
                break;
            }
        }
    }

    private void applyGravity() {
        // Logic to apply gravity to the character
        // Example: Move the character downwards
        currentY += 5; // Adjust this value to control the gravity effect
        character.setY(currentY);
        if (currentY >= findViewById(R.id.gameLayout).getHeight() - character.getHeight()) {
            isJumping = false;
        }
    }

    private void updateScore() {
        // Logic to update the score
        score++;
        scoreText.setText("Score: " + score);
    }

    private void gameOver() {
        // Logic to handle game over
        isGameFinished = true;
        gameHandler.removeCallbacksAndMessages(null);
        Toast.makeText(MainActivity.this, "Game Over! Final Score: " + score, Toast.LENGTH_LONG).show();
        savePlayerLog(username, score);
    }

    private void promptUsername() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter your username");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                username = input.getText().toString();
                startGame();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void startGame() {
        score = 0;
        scoreText.setText("Score: " + score);
        isGameFinished = false;
        findViewById(R.id.gameLayout).setEnabled(true);

        countDownTimer = new CountDownTimer(START_TIME_IN_MILLIS, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Update timer
            }

            @Override
            public void onFinish() {
                findViewById(R.id.gameLayout).setEnabled(false);
                isGameFinished = true;
                Toast.makeText(MainActivity.this, "Time's up! Final Score: " + score, Toast.LENGTH_LONG).show();
                savePlayerLog(username, score);
            }
        }.start();
    }

    private void savePlayerLog(String username, int score) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> playerData = new HashMap<>();
        playerData.put("username", username);
        playerData.put("score", score);

        db.collection("playerLogs")
                .add(playerData)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(MainActivity.this, "Score saved", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(MainActivity.this, "Error saving score", Toast.LENGTH_SHORT).show();
                });
    }
}