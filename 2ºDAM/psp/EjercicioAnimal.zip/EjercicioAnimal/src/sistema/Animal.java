package sistema;

public interface Animal {
    void comer();
    void dormir();
    void hacerSonido();
}