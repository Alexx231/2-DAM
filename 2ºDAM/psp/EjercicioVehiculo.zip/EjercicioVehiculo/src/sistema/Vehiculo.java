package sistema;

interface Vehiculo {
	
	public void acelerar();
	
	public void frenar();
	
	public int obtenerVelocidad();

}
