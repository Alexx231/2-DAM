package sistema;

public interface Dispositivo {

	void encender();
	void apagar();
	void mostrarEstado();
	
}
