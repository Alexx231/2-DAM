import pandas as pd
import numpy as np
from scipy import stats

def calcular_estadisticas(df):
    # Diccionario para almacenar las estadísticas de cada columna
    estadisticas = {}
    
    # Iterar sobre cada columna del DataFrame
    for column in df.columns:
        # Verificar si el tipo de datos de la columna es numérico (int64 o float64)
        if df[column].dtype in ['int64', 'float64']:
            # Calcular la media de la columna
            media = df[column].mean()
            # Calcular la varianza de la columna
            varianza = df[column].var()
            # Calcular la moda de la columna
            moda = stats.mode(df[column])[0][0]
            # Almacenar las estadísticas en el diccionario
            estadisticas[column] = {'media': media, 'varianza': varianza, 'moda': moda}
    
    # Devolver el diccionario con las estadísticas
    return estadisticas