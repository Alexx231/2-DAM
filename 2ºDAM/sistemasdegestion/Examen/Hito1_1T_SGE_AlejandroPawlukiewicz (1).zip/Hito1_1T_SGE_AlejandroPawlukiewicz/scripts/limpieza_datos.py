import pandas as pd
import numpy as np

def limpiar_dataframe(df):
    # Elimina filas y columnas que están completamente vacías en el DataFrame
    df.dropna(how='all', inplace=True)
    df.dropna(axis=1, how='all', inplace=True)
    return df

def reemplazar_nan_por_cero(df):
    # Reemplaza los valores NaN en el DataFrame por 0
    return df.fillna(0)

def limpiar_datos_incorrectos(df):
    # Reemplaza valores negativos por 0 en columnas numéricas y convierte columnas no numéricas a cadenas de texto
    for column in df.select_dtypes(include=[np.number]).columns:
        df[column] = df[column].clip(lower=0)  # Reemplaza valores negativos por 0
    for column in df.select_dtypes(exclude=[np.number]).columns:
        df[column] = df[column].astype(str)
    return df