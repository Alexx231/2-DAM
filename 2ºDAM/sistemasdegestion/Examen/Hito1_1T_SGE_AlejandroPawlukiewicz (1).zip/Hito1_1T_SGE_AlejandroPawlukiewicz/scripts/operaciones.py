def guardar_datos_concatenados(colecciones_datos, archivo_salida, encoding='utf-8'):
    # Abre el archivo de salida en modo escritura con la codificación especificada
    with open(archivo_salida, 'w', encoding=encoding) as file:
        # Itera sobre cada colección de datos
        for coleccion in colecciones_datos:
            # Verifica si la colección es una lista, tupla o conjunto
            if isinstance(coleccion, (list, tuple, set)):
                # Itera sobre cada dato en la colección y lo escribe en el archivo
                for dato in coleccion:
                    file.write(f"{dato}\n")
            else:
                # Si la colección no es una lista, tupla o conjunto, escribe el dato directamente en el archivo
                file.write(f"{coleccion}\n")