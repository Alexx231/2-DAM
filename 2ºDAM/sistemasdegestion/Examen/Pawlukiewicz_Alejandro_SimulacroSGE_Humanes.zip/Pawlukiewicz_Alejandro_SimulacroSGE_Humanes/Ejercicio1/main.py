import modulo_calculadora

def main():
    try:
        a = float(input("Introduce el primer número: "))
        b = float(input("Introduce el segundo número: "))
        operacion = input("Introduce la operación ('+' o '-'): ")

        if operacion == '+':
            resultado = modulo_calculadora.sumar(a, b)
        elif operacion == '-':
            resultado = modulo_calculadora.restar(a, b)
        else:
            print("Operación no soportada.")
            return

        print(f"El resultado es: {resultado}")

    except ValueError:
        print("Entrada inválida. Por favor, introduce números válidos.")
        
main()