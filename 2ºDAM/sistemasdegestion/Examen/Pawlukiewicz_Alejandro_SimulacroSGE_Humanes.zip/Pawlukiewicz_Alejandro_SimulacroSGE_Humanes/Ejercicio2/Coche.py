from Vehiculo import Vehiculo

class Coche (Vehiculo):
    def __init__(self,marca, modelo, puertas):
        super().__init__(marca, modelo)
        self.puertas = puertas
        
    def descripcion(self):
        return super().descripcion() + f" - Puertas: {self.puertas}"