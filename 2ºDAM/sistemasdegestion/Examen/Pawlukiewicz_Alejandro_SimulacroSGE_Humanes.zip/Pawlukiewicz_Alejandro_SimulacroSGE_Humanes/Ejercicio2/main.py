from Coche import Coche

def main():
    try:
        marca = input("Introuce la marca del coche: ")
        modelo = input("Introduce el modelo del coche:")
        puertas = int(input("Introduce el numero de puertas del coche:"))
        
        print("\n Creando coche...")
        
        coche = Coche(marca, modelo, puertas)
        
        print(coche.descripcion())
    
    except ValueError:
        print("Entrada inválida.")

main()