import unittest
from calcular_area import calcular_area

class TestCalcularArea(unittest.TestCase):

    def test_area_positiva(self):
        self.assertEqual(calcular_area(10, 5), 25)
        self.assertAlmostEqual(calcular_area(3.5, 6.7), 11.725)

    def test_valores_negativos(self):
        self.assertEqual(calcular_area(-10,5), -25)
        self.assertEqual(calcular_area(3, -6), -9)
        
    def test_valores_no_numericos(self):
        self.assertEqual(calcular_area("a", "b"), "ab")
        self.assertEqual(calcular_area("B", "A"), "BA")
        
unittest.main()
