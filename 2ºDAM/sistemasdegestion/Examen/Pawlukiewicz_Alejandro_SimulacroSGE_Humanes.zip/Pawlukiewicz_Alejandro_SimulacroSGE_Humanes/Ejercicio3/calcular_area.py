def calcular_area(base, altura):
    return 0.5 * base * altura

def test_valor_negativo(base, altura):

    if base < 0 or altura < 0:
        raise ValueError("Valores inválidos")
    
def test_valor_no_numerico(base,altura):
    if base == float and altura == float:
        pass
    else :
        return ValueError("No se puede calcular el area con valores no numericos")
    