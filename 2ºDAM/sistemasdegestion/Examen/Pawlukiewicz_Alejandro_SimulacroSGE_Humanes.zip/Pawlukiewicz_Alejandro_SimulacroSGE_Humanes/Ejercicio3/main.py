from calcular_area import calcular_area, test_valor_negativo, test_valor_no_numerico

def main():
    try:
        base = float(input("Introduce la base del triangulo:"))
        altura = float(input("Introduce la altura del triangulo:"))
        
        test_valor_negativo(base, altura)
        test_valor_no_numerico(base, altura)
        
        print(f"El area del triangulo es: {calcular_area(base, altura)}")
        
    except ValueError:
        print("Entrada inválida.")
        

main()