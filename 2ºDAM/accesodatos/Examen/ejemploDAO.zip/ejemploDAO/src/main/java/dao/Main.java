package dao;
import java.util.List;

import dao.RepositorioCategoriaDAO;
import dao.model.Categoria;
import dao.model.Producto;

public class Main {

    public static void main(String[] args) {
        RepositorioCategoriaDAO repoCategoria = new RepositorioCategoriaDAO();

        List<Categoria> lista = repoCategoria.getList();

        for (Categoria c : lista) {
            System.out.println(c);
            List<Producto> listProductos = repoCategoria.getList(c.getIdcategoria());
            for (Producto p : listProductos) {
                System.out.println("     " + p.getNombre() + " - " + p.getPrecio());
            }
        }
    }
}