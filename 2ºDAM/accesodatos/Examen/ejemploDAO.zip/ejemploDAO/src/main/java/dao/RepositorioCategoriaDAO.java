package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dao.model.Categoria;
import dao.model.Producto;

public class RepositorioCategoriaDAO 
	implements RepositorioDAO<Categoria, Integer>{

	@Override
	public boolean add(Categoria data) {
		try {
			PreparedStatement ps = ConexionBD.getConexion().prepareStatement("INSERT INTO CATEGORIA VALUES (?, ?)");
			ps.setInt(1, data.getIdcategoria());
			ps.setString(2, data.getCategoria());
			int n = ps.executeUpdate();
			if (n>0) return true; else return false;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean remove(Integer id) {
		try {
			PreparedStatement ps = ConexionBD.getConexion().prepareStatement("DELETE FROM CATEGORIA WHERE idCategoria = ?");
			ps.setInt(1, id);
			int n = ps.executeUpdate();
			if (n>0) return true; else return false;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public Categoria findById(Integer id) {
		Categoria c = null;
		try {
			PreparedStatement ps = ConexionBD.getConexion().prepareStatement("SELECT * FROM CATEGORIA WHERE idCategoria = ?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			boolean encontrado = rs.next();
			if (encontrado) {
				c = new Categoria();
				c.setIdcategoria(rs.getInt("idCategoria"));
				c.setCategoria(rs.getString("Categoria"));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}

	@Override
	public boolean update(Categoria data) {
		// Actualiza el nombre de la categoría.
		// El id lo utiliza cómo clave de búsqueda.
		try {
			PreparedStatement ps = ConexionBD.getConexion().prepareStatement("UPDATE CATEGORIA SET Categoria = ? WHERE idCategoria = ?");
			ps.setString(1, data.getCategoria());
			ps.setInt(2, data.getIdcategoria());
			int n = ps.executeUpdate();
			if (n>0) return true; else return false;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public List<Categoria> getList() {
		String sql = "SELECT * FROM Categoria";
		List<Categoria> categorias = new ArrayList<Categoria>();
		try {
			Statement statement = ConexionBD.getConexion().createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				Categoria c = new Categoria();
				c.setIdcategoria(rs.getInt("IdCategoria"));
				c.setCategoria(rs.getString("Categoria"));
				categorias.add(c);
			}
		} catch (SQLException e) { }
		
		return categorias;
	}	

	public List<Producto> getList(Integer id) {
		String sql = "SELECT * FROM PRODUCTO WHERE idCategoria = " + id;
		List<Producto> productos = new ArrayList<Producto>();
		try {
			Statement statement = ConexionBD.getConexion().createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				Producto p = new Producto();
				p.setNombre(rs.getString("nombre"));
				p.setStock(rs.getInt("Stock"));
				p.setPrecio(rs.getInt("precio"));

				productos.add(p);
			}
		} catch (SQLException e) { }
		
		return productos;
	}	
}
