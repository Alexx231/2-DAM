package aspect.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        try {
            ApplicationContext context = new ClassPathXmlApplicationContext("configBeans.xml");
            Obra obra = context.getBean("obra", Obra.class);
            
            obra.comenzarObra();
            obra.descanso();
            obra.reanudarObra();
            obra.finObra();
        } catch (Exception e) {
            System.out.println("Excepción capturada: " + e.getMessage());
        }
    }
}