package aspect.aop;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component

public class PublicoAspecto {
    
    private Publico publico = new Publico();
    
    @Before("execution(* Obra.comenzarObra(..))")
    public void antesDeComenzar() {
        publico.sentarse();
    }
    
    @Before("execution(* Obra.reanudarObra(..))")
    public void antesDeReanudar() {
        publico.sentarse();
    }
    
    @AfterReturning("execution(* Obra.descanso(..))")
    public void despuesDelDescanso() {
        publico.descanso();
    }
    
    @AfterReturning("execution(* Obra.finObra(..))")
    public void alTerminar() {
        publico.aplaudir();
        publico.aCasa();
    }
    
    @AfterThrowing("execution(* Obra.finObra(..))")
    public void siAlgoSaleMal() {
        publico.abuchear();
        publico.aCasa();
    }
}