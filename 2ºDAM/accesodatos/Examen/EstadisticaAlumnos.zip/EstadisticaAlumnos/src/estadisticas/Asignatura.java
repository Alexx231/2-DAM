package estadisticas;

public enum Asignatura {
    MATEMATICAS,
    LENGUA,
    CIENCIAS,
    HISTORIA,
    INGLES,
    FISICA,
    QUIMICA
}