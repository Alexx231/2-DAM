package es.fiesta;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "es.fiesta")
public class Config {

    @Bean
    public Coche coche() {
        return new Coche();
    }

    @Bean
    public Fiestero fiestero() {
        Fiestero fiestero = new Fiestero();
        fiestero.setCoche(coche());
        return fiestero;
    }

    @Bean
    public Fiesta fiesta() {
        Fiesta fiesta = new Fiesta();
        fiesta.setFiestero(fiestero());
        return fiesta;
    }
}